package TesteEntityManagerUtil;

import org.junit.Test;
import util.EntityManagerUtil;

public class TesteEntityManagerUtil {

	@Test
	public void connectionTest() {

		EntityManagerUtil.getEntityManager();

	}

}